package Assignment;

public class Laptop extends Computer{
    private double screenSize;

    public Laptop(String manufacturer, String processor, int ramSize, double processorSpeed, double screenSize) {
        super(manufacturer, processor, ramSize, processorSpeed);
        this.screenSize = screenSize;
    }

    @Override
    public double getPayment() {
        return 1200.0;
    }
}

