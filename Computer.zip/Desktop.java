package Assignment;

public class Desktop extends Computer{
    private String formFactor;

    public Desktop(String manufacturer, String processor, int ramSize, double processorSpeed, String formFactor) {
        super(manufacturer, processor, ramSize, processorSpeed);
        this.formFactor = formFactor;
    }

    @Override
    public double getPayment() {
        // Implement payment calculation for Desktop
        return 1000.0;
    }
}

