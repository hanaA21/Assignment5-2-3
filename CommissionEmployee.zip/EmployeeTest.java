package Assignment;

public class EmployeeTest {
    public static void main(String[] args) {
        Employee[] employees = new Employee[5];

        employees[0] = new CommissionEmployee("Alex", "Steven", "939-55-6729", 50000, 0.05);
        employees[1] = new BasePlusCommissionEmployee("Hellen", "Smith", "987-65-4321", 100000, 0.03, 2000);
        employees[2] = new HourlyEmployee("Bob", "Johnson", "869-56-7890", 15, 40);
        employees[3] = new SalariedEmployee("Mike", "Williams", "435-41-8901", 800);
        employees[4] = new CommissionEmployee("Robert", "Brown", "221-98-0123", 75000, 0.04);

        for (Employee employee : employees) {
            System.out.println(employee);
            System.out.println("Payment: " + employee.getPayment());
            System.out.println("------------------------");
        }
        double totalSalaries = 0;
        for (Employee employee : employees) {
            totalSalaries += employee.getPayment();
        }
        System.out.println("Total Salaries: " + totalSalaries);
    }
}

