package Assignment;

public interface Figure {
    void getFigure();
}
class UpwardHat implements Figure {
    @Override
    public void getFigure() {
        System.out.print("/\\ ");
    }
}

class DownwardHat implements Figure {
    @Override
    public void getFigure() {
        System.out.print("\\/ ");
    }
}

class FaceMaker implements Figure {
    @Override
    public void getFigure() {
        System.out.print(":) ");
    }
}

class Vertical implements Figure {
    @Override
    public void getFigure() {
        System.out.print("|| ");
    }
}
